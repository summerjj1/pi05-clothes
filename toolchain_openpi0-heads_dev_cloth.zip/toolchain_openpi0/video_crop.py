import os
import subprocess
import cv2

input_dir = "/mnt/petrelfs/zhouyunsong/tmp/ebench_t/arx_lift2/transformed_data/Make_a_beef_sandwich/videos_raw/chunk-000/images.rgb.hand_right"
output_dir = "/mnt/petrelfs/zhouyunsong/tmp/ebench_t/arx_lift2/transformed_data/Make_a_beef_sandwich/videos/chunk-000/images.rgb.hand_right"
os.makedirs(output_dir, exist_ok=True)

for fname in os.listdir(input_dir):
    if not fname.endswith(".mp4"):
        continue

    in_path = os.path.join(input_dir, fname)
    out_path = os.path.join(output_dir, fname)

    # 用 OpenCV 先探测分辨率
    cap = cv2.VideoCapture(in_path)
    if not cap.isOpened():
        print(f"❌ 无法打开视频: {in_path}")
        continue
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    cap.release()

    if (height, width) == (480, 640):
        # y_offset = (480 - 368) // 2 = 56
        crop_filter = "crop=640:368:0:56"
        cmd = [
            "ffmpeg", "-y", "-i", in_path,
            "-vf", crop_filter,
            "-c:v", "libx264", "-crf", "18", "-preset", "fast",  # H.264 编码
            "-c:a", "copy",  # 保持原音频
            out_path
        ]
        print(f"✂️ 裁剪视频: {fname}")
        subprocess.run(cmd, check=True)
    else:
        print(f"✅ 保持原样: {fname}")
        # 如果你希望非 480x640 的视频也拷贝到输出目录，可以加：
        # subprocess.run(["cp", in_path, out_path])
