import cv2
import os

folder = "/mnt/petrelfs/zhouyunsong/tmp/ebench_t/arx_lift2/transformed_data/Make_a_beef_sandwich/videos/chunk-000/images.rgb.hand_right"  # 这里改成你的视频文件夹路径

for fname in os.listdir(folder):
    if fname.endswith(".mp4"):
        fpath = os.path.join(folder, fname)
        cap = cv2.VideoCapture(fpath)
        if not cap.isOpened():
            print(f"❌ Cannot open {fname}")
            continue
        
        width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        channels = 3  # mp4 默认是彩色视频
        
        print(f"{fname}: resolution=({height},{width},{channels})")
        
        # if (height, width, channels) == (368, 640, 3):
        #     print(f"✅ Found target shape (368,640,3): {fname}")
        
        cap.release()
