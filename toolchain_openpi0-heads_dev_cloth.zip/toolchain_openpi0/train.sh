#!/usr/bin/bash

export HF_LEROBOT_HOME='/mnt/petrelfs/zhouyunsong/tmp/ebench_t/arx_lift2'
export WANDB_MODE=offline
export JAX_LOG_COMPILES=1
export XLA_FLAGS=--xla_dump_to=./tmp/xla_dump
# export XLA_FLAGS=--xla_gpu_persistent_cache_dir=./tmp/xla_cache


cd /mnt/petrelfs/zhouyunsong/zhouys/git_code/toolchain_openpi0
python scripts/compute_norm_stats.py --config-name 20251212_pi0_cloth_sim
XLA_PYTHON_CLIENT_MEM_FRACTION=0.9  python scripts/train.py  20251212_pi0_cloth_sim --exp-name=my_experiment --overwrite