# export XLA_FLAGS="--xla_dump_to=./tmp/xla_cache"
XLA_PYTHON_CLIENT_MEM_FRACTION=0.9 python scripts/train.py debug --exp-name=my_experiment --overwrite